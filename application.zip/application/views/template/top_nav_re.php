   <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php base_url(); ?>admin"> <img height="50" width="80" alt="Myhealth Logo" src="<?php echo base_url();?>public/img/logo.png" class="hidden-xs"/>
             <!-- <span>SocialApp</span>  --></a>
        </div>
    </div>
