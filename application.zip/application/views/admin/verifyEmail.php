<div class="row">
        <div class="col-md-12 center login-header">
            <h2>Welcome to Myhealth</h2>
        </div>
        <!--/span-->
    </div><!--/row-->

    <div class="row">
        <div class="well col-md-5 center login-box">
            <div class="alert alert-info">
                <?php echo "Your email have been succesfully verified." ?>
            </div>
          
        
               
            
        </div>
        <!--/span-->
    </div><!--/row-->
